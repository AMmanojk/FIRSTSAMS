<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>SMAS</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="" />
<meta name="author" />
<!-- css -->
<link href="css/bootstrap.min.css" rel="stylesheet" />
<link href="css/fancybox/jquery.fancybox.css" rel="stylesheet">
<link href="css/jcarousel.css" rel="stylesheet" />
<link href="css/flexslider.css" rel="stylesheet" />
<link href="js/owl-carousel/owl.carousel.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet" />
 
<style>
	nav {
  float: left;
  width: 20%;
  height: 11.5cm; 
  background: #2F3A58;
}

.inset {border-style: inset;
	margin-right: auto;
	border-color: #616f97;
	border-radius: 20px;
	height: 11.5cm;
	width: 100%;
}

	.avatar {
	  vertical-align: middle;
	  margin-top: 80px;
	  margin-left: 30px;
	  width: 250px;
	  height: 150px;
	  border-radius: 80%;
	}

	.ab{
		font-family: Arial, Helvetica, sans-serif;
		font-style: normal;
		color: black;
		font-size: medium;
	}
	 



	</style>

</head>
<body>

	
	<header>
        <div class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" ><img src="icon.jfif" alt="logo"/></a>
                </div>
                <div class="navbar-collapse collapse ">
                    <ul class="nav navbar-nav">
                        <li><a href="dashboard.php">DASHBOARD</a></li> 
						  
						<li><a href="overall.php">ATTENDANCE REPORT</a></li>
                        <li ><a href="apply.php">APPLY LEAVE</a></li>
						<li><a href="fed.php">FEEDBACK</a></li>
                        <li><a href="profile.php">PROFILE</a></li>
                        <li><a href="logout.php">LOGOUT</a></li>
                    </ul>
                </div>
            </div>
        </div>
	</header>
	<section id="banner">
	 
	
	</section> 
	<section id="call-to-action-2">
		<div class="container">
			<div class="row">
				<div class="col-md-10 col-sm-9">
					<h3>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
						&nbsp;&nbsp;Welcome Student Name</h3>
					
				</div>
				
			</div>
		</div>
	</section>


	<section>
		<nav>	
			<img src="male.jfif" alt="Avatar" class="avatar">
		</nav>
		<div  class ='inset'><h1 class="ab" >&nbsp;&nbsp;&nbsp;EVENTS<br></h1>
			
				<b class ='ab'>Apply for the UGADI_2022! and get exciting gifts<br>					
					&nbsp;<marquee behavior="scroll" direction="left" scrollamount="8" width=" 80%"><a style="color:red" href="https://intranet.cb.amrita.edu/aums">Cick here to Apply!</a></marquee>					
					<br class="ab">Circular - Commencement of offline class for 2019 batch B.Tech and five year Integrated programs at Amrita School of Engineering.
					<marquee behavior="scroll" direction="left" scrollamount="13" width=" 80%"><a class="ab" style="color:red;"  href="https://intranet.cb.amrita.edu/statutory-and-other-committees-members/anti-ragging-committee">Cick here to Apply!</br></marquee>
					</a>
					<br class="ab">IPL is coming - Want to play cricket in amrita<a href="#" </b>
					</h1>

					

				</div>
			
			
		
		
		
		
			
	  </section>
	
	
	
</body>
</html>